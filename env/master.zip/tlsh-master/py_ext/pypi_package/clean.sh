#!/bin/sh

echo "rm -rf build dist py_tlsh.egg-info"
      rm -rf build dist py_tlsh.egg-info
